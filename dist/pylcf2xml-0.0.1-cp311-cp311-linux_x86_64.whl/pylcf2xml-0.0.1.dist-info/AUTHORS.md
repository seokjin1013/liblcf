liblcf authors
==============

* Alejandro Marzini (vgvgf)
* Carsten Teibes (carstene1ns)
* Gabriel Kind (Ghabry)
* Glynn Clements (glynnc)
* Matthew Fioravante (fmatthew5876)
* Paulo "Zhek" Vizcaino (paulo_v)
